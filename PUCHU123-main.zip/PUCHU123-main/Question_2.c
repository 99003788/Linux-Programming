#include<unistd.h>
#include<fcntl.h>

#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int main() {
  /*Read the file.*/

  int fd,nbytes;
  char ch;
  int char_count = 0, word_count = 0, line_count = 0;
  int MAX_LEN = 300;
  char buf[MAX_LEN];
  char s1[MAX_LEN];
    fd = open("source.txt", O_RDONLY);
    if(fd<0)
	{
		perror("open");
		exit(1);
	}
   nbytes = read(fd,buf,MAX_LEN);
  //write(1,buf,nbytes);;
  strcpy(s1,buf);
 for(ch=0;s1[ch]!= '\0' ;ch++)
    {
        char_count++;

        /* Check new line */
        if (s1[ch] == '\n')
            line_count++;

        /* Check words */
        if (s1[ch] == ' ' || s1[ch] == '\t' || s1[ch] == '\n' || s1[ch] == '\0')
            word_count++;
    }
    /* Increment words and lines for last word */
    if (char_count > 0)
    {
        word_count++;
        line_count++;
    }
    printf("\n");
    /* Print file statistics */
    printf("Total characters = %d\n", char_count);
    printf("Total words      = %d\n", word_count);
    printf("Total lines      = %d\n", line_count);


    /* Close files to release resources */

  close(fd);
  return 0;
}