Process_3
Commands: gcc Process_3.c -o test
	  ./test calc.c add.c sub.c

Process_2
Commands: gcc Process_2.c -o test
	  ./test hello.c

Process_1
Commands:  gcc Process_1.c -o test
	   ./test ls(any 1 command can be given like ps, top, ls -l, wc)