#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "box.h"
#include "unistd.h"

int add_box(box_t* ptrbox, box_t* box)
{
  //  printf("ptr_box = %p, box = %p", ptrbox, box);
  if(NULL == ptrbox || NULL == box) 
    return -1;

memcpy(ptrbox, box, sizeof(box_t));
return 0;
}

int display1(const box_t* ptrbox)
{
  //  printf("ptr_box = %p, box = %p", ptrbox, box);
  if(NULL == ptrbox ) 
    return -1;

    for(int i =0; i< 2; i++)
        {
            printf("ID = %d\nbreadth= %d", ptrbox[i].unique_id, ptrbox[i].breadth);
        }
return 0;
}
/**
 * @brief takes the details of the box : unique ID,length,breadth,height,Colour,weight
 * 
 * @param  / arguments pointer to structure
 * @return int (returns successful entering 10 box details)
 */
void enter_details(struct box *pb)
{
    int i;
    for(i=0;i<SIZE;i++)
    {
        printf("Enter details:unique ID,length,breadth,height,colour,weight\n");
        scanf("%d%d%d%d%s%lf",&pb[i].unique_id,&pb[i].length,&pb[i].breadth,&pb[i].height,pb[i].colour,&pb[i].weight);
    }
       
}

//add_box(box_t* box_ptr, box_t*  )
/**
 * @brief displays the details of the box
 * 
 * @param /arguments pointer to structure
 * @return pointer holding first box address
 */
struct box display(struct box *pb)
{
    int i;
    printf("\n Details of the boxes");
    for(i=0;i< SIZE;i++)
        {
            printf("\n Unique ID = %d \t Lenght = %d \t Breadth = %d \t Height = %d \n colour = %s \t Weight = %lf",pb[i].unique_id,pb[i].length,pb[i].breadth,pb[i].height,pb[i].colour,pb[i].weight);
        }
    return *pb;
}

/**
 * @brief To find the maximum height
 * 
 * @param pb num Integer to find height
 * @return int Success or Failure
 */

int max_height(struct box *ptr)
{
    if(SIZE<1)
    {
        return 0; 
    }
    else
    {
        int maxH=0,i;
        for(i = 0; i < SIZE; i++)
            {
                if(maxH < ptr[i].height)
                {
                    maxH = ptr[i].height;
                    break;
                }
            }
            return 1;
}
}
/**
 * @brief To update weight of box with specific id
 * 
 * @param pb num Integer and double to update weight
 * @return int Success or Failure
 */
int update_weight(struct box *pb)
{
    int id,j,i;
    double new;
    printf("\n Enter ID to change the weight the box");
    scanf("%d",&id);
    for(i=0;i<SIZE;i++)
    {
        if(pb->unique_id==id)
        {   
            pb->weight = new;
            printf("\n Unique ID = %d \t Lenght = %d \t Breadth = %d \t Height = %d \n colour = %s \t Weight = %lf",pb[i].unique_id,pb[i].length,pb[i].breadth,pb[i].height,pb[i].colour,pb->weight);
             return 1;
        }
        else
        {
            printf("\n Box not found");
            return 0;
        }
    }
}
/**
 * @brief Remove the box with given id
 * 
 * @param pb num Integer to remove the box
 * @return int Success or Failure
 */

int remove_box(struct box *pb)
{
    int id,j,i;
    double new;
        for(i=0;i<SIZE;i++)
    {
        if(pb->unique_id==id)
        {
            
            pb->weight = new;
            printf("\n Unique ID = %d \t Lenght = %d \t Breadth = %d \t Height = %d \n colour = %s \t Weight = %lf",pb[i].unique_id,pb[i].length,pb[i].breadth,pb[i].height,pb[i].colour,pb->weight);
             return 1;
        }
        else
        {
            printf("\n Box not found");
            return 0;
        }
    }
    
}


/**
 * @brief Find the box with given id
 * 
 * @return int Success or Failure
 */


int find_box_by_id(struct box* parr)
{

 int u_id = 3;
	for(int i=0;i<SIZE;i++)
	{
		if (parr[i].unique_id==u_id)
		{
            printf("The box has been found\n");
			return 1;
		}
        parr++;
     	
	}
    printf("The box with the given unique_id is not present\n");
    return 0;

}   


	
/**
 * @brief to find the average volume of all the boxes
 * 
 * @param pointer pointing to first box
 * 
 * @return average volume
 * 
 */

int avg_vol(struct box *pb)
{
    
    int sum=0,i;
    float avg = 0;
    
    for( i = 0 ; i < SIZE ; i++ )
    {
        sum += (pb[i].length) * (pb[i].breadth) * (pb[i].height) ;
    }
    avg = sum / SIZE ;
     return 1;
}

	
/**
 * @brief to find the difference between maximum and minimum volume
 * 
 * @param pointer pointing to first box
 * 
 * @return difference between maximum and minimum volume
 * 
 */

int difference(struct box *pb)
{
    int max = 0,i,volume=0 ;
    long min = 1000000 ;
    for(i=0; i<SIZE ; i++)
    {
        volume=(pb[i].length)*(pb[i].breadth)*(pb[i].height);
        
        if(volume > max)
            max = volume ;
        if(volume < min)
            min = volume ;
    }
    
    return (max - min) ;
}
