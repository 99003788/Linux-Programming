
#include "unity.h"
#include "inc/box.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "unity_internals.h"

#define SUCCESS 1
#define ZERO 0
box_t (*pb)[SIZE] = NULL;

box_t b1 = {1,2,3, 4, "red", 1.2};
box_t b2 = {2,2,3, 4, "red", 1.2};
box_t b3 = {3,2,3, 4, "red", 1.2};
box_t b4 = {4,2,3, 4, "red", 1.2};
box_t b5 = {5,2,3, 4, "red", 1.2};

/* Required by the unity test framework */
void setUp(){
      pb = malloc(sizeof(box_t) * SIZE);
}
/* Required by the unity test framework */
void tearDown(){
      free(pb);
}



void test_update_weight(void)
{
      TEST_ASSERT_EQUAL(SUCCESS, update_weight(pb));
    
}

void test_remove_box(void)
{
      TEST_ASSERT_EQUAL(SUCCESS, remove_box(pb));
    
}
/*
void test_max_height(void)
{
    TEST_ASSERT_EQUAL(SUCCESS,max_height(pb));
}
*/
void test_find_box_by_id(void)
{
      TEST_ASSERT_EQUAL(SUCCESS,find_box_by_id(pb));
}
void test_add()
{
  //    TEST_ASSERT_EQUAL(-1,add_box(NULL, &b1));
  //    TEST_ASSERT_EQUAL(-1,add_box(NULL, NULL));
      TEST_ASSERT_EQUAL(-1,add_box(pb, NULL));
      TEST_ASSERT_EQUAL(0,add_box(pb, &b1));
      TEST_ASSERT_EQUAL(0, add_box((*pb)+1, &b2));
      display1(pb);

}
int main(void)
{

  //struct box *p = (struct box *)malloc(SIZE * sizeof(struct box));
/* Initiate the Unity Test Framework */
  UNITY_BEGIN();
 // enter_details(pb);
  RUN_TEST(test_add);
  
 /* Close the Unity Test Framework */
 //free(p);
  return UNITY_END();

}

