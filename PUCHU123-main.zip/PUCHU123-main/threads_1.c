#include<pthread.h>
#include<stdio.h>

int a[10]={10.20,30,40,50,60,70,80,90,110}; 
double sum = 0;

void* task_body1(void* p)
{
	int i;
	printf("A--welcome\n");
	for(i=0;i<5;i++)
		sum += a[i];
	//pthread_exit(NULL);
}
void* task_body2(void *p)
{
	int i;
	printf("B--welcome\n");
	for(i=5;i<10;i++)
		sum += a[i];
	//pthread_exit(NULL);
}
void* task_body2(void *p)
{
	int i;
	printf("B--welcome\n");
	for(i=5;i<10;i++)
		sum += a[i];
	//pthread_exit(NULL);
}
void* task_body2(void *p)
{
	int i;
	printf("B--welcome\n");
	for(i=5;i<10;i++)
		sum += a[i];
	//pthread_exit(NULL);
}
void* task_body2(void *p)
{
	int i;
	printf("B--welcome\n");
	for(i=5;i<10;i++)
		sum += a[i];
	//pthread_exit(NULL);
}
void* task_body2(void *p)
{
	int i;
	printf("B--welcome\n");
	for(i=5;i<10;i++)
		sum += a[i];
	//pthread_exit(NULL);
}
int main()
{
	//int i;
	f//or (i = 0; i < 10; i++) {
    //a[i] = rand();
	//}
	pthread_t pt1,pt2,pt3,pt4,pt5,pt6.pt7,pt8,pt9,pt10;	//thread handle
	pthread_create(&pt1,NULL,task_body1,NULL);
	pthread_create(&pt2,NULL,task_body2,NULL);
	pthread_create(&pt3,NULL,task_body2,NULL);
	pthread_create(&pt4,NULL,task_body2,NULL);
	pthread_create(&pt5,NULL,task_body2,NULL);
	pthread_create(&pt6,NULL,task_body2,NULL);
	pthread_create(&pt7,NULL,task_body2,NULL);
	pthread_create(&pt8,NULL,task_body2,NULL);
	pthread_create(&pt9,NULL,task_body2,NULL);
	pthread_create(&pt10,NULL,task_body2,NULL);

	pthread_join(pt1,NULL);
	pthread_join(pt2,NULL);
	printf("%lf\n",sum);
	printf("main--thank you\n");
	return 0;	//exit(0);
}












/*
#include <stdio.h> 
#include <pthread.h> 
  
// size of array 
#define MAX 16 
  
// maximum number of threads 
#define MAX_THREAD 10 
  

int part = 0; 
  
void* sum_array(void* arg) 
{ 
  
    // Each thread computes sum of 1/4th of array 
    int thread_part = part++; 
  
    for (int i = thread_part * (MAX / 10); i < (thread_part + 1) * (MAX / 10); i++) 
        sum[thread_part] += a[i]; 
} 
 
// Driver Code 
int main() 
{ 
	
    pthread_t threads[MAX_THREAD]; 
  
    // Creating 4 threads 
    for (int i = 0; i < MAX_THREAD; i++) 
        pthread_create(&threads[i], NULL, sum_array, (void*)NULL); 
  
    // joining 4 threads i.e. waiting for all 4 threads to complete 
    for (int i = 0; i < MAX_THREAD; i++) 
        pthread_join(threads[i], NULL); 
  
    // adding sum of all 4 parts 
    int total_sum = 0; 
    for (int i = 0; i < MAX_THREAD; i++) 
        total_sum += sum[i]; 
  
    printf("sum is %d",total_sum); 
  
    return 0; 
} 
*/

