#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h>

int main()
{
	int ret,i,status;
    char s1[100];
    printf("Enter command:\n");
    scanf("%s",s1);
	printf("welcome..pid=%d\n",getpid());
	ret=fork();
	if(ret<0)
	{
		perror("fork");
		exit(1);
	}
	if(ret==0)
	{
		printf("child--welcome,pid=%d,ppid=%d\n",
			getpid(),getppid());
		for(i=1;i<=5;i++)
		{
			printf("child--pid=%d,ppid=%d\n",
				getpid(),getppid());
			usleep(100);
		}
		exit(5);
		//exit(0);
	}
	else	//ret>0
	{
		printf("parent--hello,pid=%d,ppid=%d\n",
			getpid(),getppid());
		//real work
		waitpid(-1,&status,0); //wait(&status);
		printf("parent--child exit status=%d\n",
			WEXITSTATUS(status));
	}
	//printf("thank you,pid=%d,ppid=%d\n",
	//		getpid(),getppid());
	return 0;
}



	
	
	
		int k;
		//char* argv[]={"cal","10","2018",NULL};
		//k=execv("/usr/bin/cal",argv);
        k=execl("/usr/bin/cal", "cal", "10", "2021", NULL); // Null must be there otherwise does not recognize
		if(k<0)
		{
			perror("execv");
			exit(1);
		}
		exit(0);
	}
	else		//ret>0
	{
		printf("parent--hello,pid=%d,ppid=%d\n",
				getpid(),getppid());
	}
	//printf("Thank you..pid=%d\n",getpid());
	return 0;
}