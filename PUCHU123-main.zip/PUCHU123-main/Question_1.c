#include<unistd.h>
#include<fcntl.h>

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char *argv[])
{
	int fd,nbytes,fd2,len,len1,nbytes2;
	fd=open(argv[1],O_RDONLY);
    fd2=open("destination.txt",O_WRONLY|O_CREAT, 0666);
	if(fd<0)
	{
		perror("open");
		exit(1);
	}
    if(fd2<0)
	{
		perror("open");
		exit(1);
	}
	int maxlen=300;
	char str[maxlen];
    char s2[maxlen];
 	nbytes=read(fd,str,maxlen);
     len1 = strlen(str);
     strcpy(s2,str);
     //s2[len1++] = '\0';
    if(nbytes<0)
	{
		perror("read");
		exit(2);
	}
     len = strlen(s2);// changed fd - 0
     nbytes2 =	write(fd2, s2, len);
	 if(nbytes2<0)
	{
		perror("write");
		exit(2);
	}
	printf("written successfully,nbytes=%d\n",nbytes2);
	close(fd2);
	close(fd);
	return 0;	//exit(0);

}
		








